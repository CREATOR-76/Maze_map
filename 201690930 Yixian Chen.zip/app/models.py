from app import db
from datetime import datetime, time

class Assessment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    module_code = db.Column(db.String(10), nullable=False)
    deadline_date = db.Column(db.Date, nullable=False, default=datetime.utcnow)
    deadline_time = db.Column(db.Time, nullable=False, default=time(23, 59))
    description = db.Column(db.Text)
    is_complete = db.Column(db.Boolean, default=False)

    __table_args__ = (db.UniqueConstraint('module_code', 'title', name='uq_module_code_title'),)

    def __repr__(self):
        return f'<Assessment {self.title}>'
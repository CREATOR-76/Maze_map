from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, TextAreaField, BooleanField
from wtforms.fields import DateField, TimeField
from wtforms.validators import DataRequired, Length, Email, ValidationError, length, Regexp
from app.models import Assessment


class AssessmentForm(FlaskForm):
    title = StringField('Title', validators=[DataRequired(), Length(max=100)])
    module_code = StringField('Module Code', validators=[DataRequired(), Regexp('^[a-zA-Z0-9]+$', message="Module code can only contain letters and numbers.")])
    deadline_date = DateField('Deadline Date', format='%Y-%m-%d', validators=[DataRequired()])
    deadline_time = TimeField('Deadline Time', format='%H:%M', validators=[DataRequired()])
    description = TextAreaField('Description', validators=[Length(max=500)])
    is_complete = BooleanField('Completed')
    submit = SubmitField('Save')

    def validate_title(self, field):
        if Assessment.query.filter_by(module_code=self.module_code.data, title=field.data).first():
            raise ValidationError(
                "An assessment with this module code and title already exists.")
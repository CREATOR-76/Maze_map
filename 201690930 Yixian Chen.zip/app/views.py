from flask import render_template, redirect, url_for, flash, jsonify
from app import app, db
from app.models import Assessment
from app.forms import AssessmentForm
from flask import request
from datetime import datetime, date, time

# Home page: displays all assessments ordered by deadline
@app.route('/')
@app.route('/index')
def index():
    assessments = Assessment.query.order_by(Assessment.deadline_date, Assessment.deadline_time).all()
    return render_template('index.html', assessments=assessments)

# Create new assessment: GET displays form, POST processes submission
@app.route('/new_assessment', methods=['GET', 'POST'])
def new_assessment():
    form = AssessmentForm()
    if form.validate_on_submit():
        deadline_date = form.deadline_date.data
        deadline_time = form.deadline_time.data
        deadline = datetime.combine(deadline_date, deadline_time)

        assessment = Assessment(title=form.title.data,
                                module_code=form.module_code.data,
                                deadline_date=deadline,
                                description=form.description.data,
                                is_complete=form.is_complete.data)
        db.session.add(assessment)
        db.session.commit()
        return redirect(url_for('index'))
    return render_template('new_assessment.html', form=form)

# Edit assessment by ID
@app.route('/edit_assessment/<int:assessment_id>', methods=['GET', 'POST'])
def edit_assessment(assessment_id):
    assessment = Assessment.query.get_or_404(assessment_id)
    form = AssessmentForm(obj=assessment)
    if form.validate_on_submit():
        assessment.title = form.title.data
        assessment.module_code = form.module_code.data
        assessment.deadline_date = datetime.combine(form.deadline_date.data, form.deadline_time.data)
        assessment.description = form.description.data
        assessment.is_complete = form.is_complete.data
        db.session.commit()
        return redirect(url_for('index'))
    return render_template('edit_assessment.html', form=form, assessment=assessment)

# Toggle assessment completion status by ID
@app.route('/mark_complete/<int:assessment_id>', methods=['POST'])
def mark_complete(assessment_id):
    assessment = Assessment.query.get_or_404(assessment_id)
    assessment.is_complete = True
    db.session.commit()
    redirect_url = request.form.get('redirect_url') or 'index'
    return redirect(url_for(redirect_url))

@app.route('/mark_incomplete/<int:assessment_id>', methods=['POST'])
def mark_incomplete(assessment_id):
    assessment = Assessment.query.get_or_404(assessment_id)
    assessment.is_complete = False
    db.session.commit()
    redirect_url = request.form.get('redirect_url') or 'index'
    return redirect(url_for(redirect_url))

# Delete assessment by ID
@app.route('/delete_assessment/<int:assessment_id>', methods=['POST'])
def delete_assessment(assessment_id):
    assessment = Assessment.query.get_or_404(assessment_id)
    db.session.delete(assessment)
    db.session.commit()
    flash('Assessment deleted!', 'success')
    redirect_url = request.form.get('redirect_url') or 'index'
    return redirect(url_for(redirect_url))

# Display incomplete assessments
@app.route('/incomplete_assessments')
def incomplete_assessments():
    incomplete_assessments = Assessment.query.filter_by(is_complete=False).all()
    return render_template('incomplete_assessments.html', assessments=incomplete_assessments)

# Display complete assessments
@app.route('/complete_assessments')
def complete_assessments():
    complete_assessments = Assessment.query.filter_by(is_complete=True).all()
    return render_template('complete_assessments.html', assessments=complete_assessments)

# Check for unique combination of module code and title via AJAX
@app.route('/check_unique_combination', methods=['POST'])
def check_unique_combination():
    data = request.get_json()
    module_code = data.get('module_code')
    title = data.get('title')
    exists = Assessment.query.filter_by(module_code=module_code, title=title).first() is not None
    return jsonify({'exists': exists})


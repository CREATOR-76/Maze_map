// Navigation Menu Toggle
// Selects the hamburger icon and navigation menu elements
const hamburger = document.querySelector(".three-line");
const navMenu = document.querySelector(".bar-menu");

// Adds a click event listener to the hamburger icon to toggle the menu visibility
hamburger.addEventListener("click", mobileMenu);
function mobileMenu() {
    hamburger.classList.toggle("active");
    navMenu.classList.toggle("active");
}

// Closes the navigation menu when a menu link is clicked
const navLink = document.querySelectorAll(".bar-a");
navLink.forEach(n => n.addEventListener("click", closeMenu));
function closeMenu() {
    if (hamburger.classList.contains("active")) {
        hamburger.classList.remove("active");
        navMenu.classList.remove("active");
    }
}

// Underline Menu Links
// Adds underline to active and hovered links for visual feedback
document.addEventListener("DOMContentLoaded", function() {
    initializeUnderline();
    handleMouseHover();
});
function initializeUnderline() {
    let currentURL = window.location.href;
    let barLinks = document.querySelectorAll('.bar-a');
    // Adds "underline" class to the link whose href matches the current URL
    barLinks.forEach(function(link) {
        if (link.href === currentURL) {
            link.classList.add('underline');
        }
    });
}
function handleMouseHover() {
    let barLinks = document.querySelectorAll('.bar-a');

    barLinks.forEach(function(link) {
        link.addEventListener('mouseenter', function() {
            link.classList.add('underline');
        });
        link.addEventListener('mouseleave', function() {
            let currentURL = window.location.href;
            if (link.href !== currentURL) {
                link.classList.remove('underline');
            }
        });
    });
}

// Verify Unique Combination of Title and Module Code
// Sets up real-time validation for title and module_code inputs
document.getElementById('title').addEventListener('input', validateUniqueCombination);
document.getElementById('module_code').addEventListener('input', validateUniqueCombination);

function validateUniqueCombination() {
    // Retrieves input values for title and module_code
    var title = document.getElementById('title').value;
    var moduleCode = document.getElementById('module_code').value;

    // Only proceeds if both fields are filled out
    if (title && moduleCode) {
        var xhr = new XMLHttpRequest();
        xhr.open('POST', '/check_unique_combination', true);
        xhr.setRequestHeader('Content-Type', 'application/json;charset=UTF-8');
        xhr.onload = function() {
            var response = JSON.parse(xhr.responseText);
            if (response.exists) {
                // Displays error if combination already exists
                document.getElementById('unique_error').innerText = "This combination of module code and title already exists.";
            } else {
                // Clears the error message if combination is unique
                document.getElementById('unique_error').innerText = "";
            }
        };
        // Sends the input data as JSON to the server
        xhr.send(JSON.stringify({ module_code: moduleCode, title: title }));
    }
}


